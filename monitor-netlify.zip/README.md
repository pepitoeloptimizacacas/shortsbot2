# Panel ShortsBot para Netlify

Este proyecto mantiene el panel protegido, la recepción de estado del PC y la orden fija de iniciar el lote.

## Despliegue

1. Crea un proyecto en Netlify desde esta carpeta o súbela como archivo ZIP.
2. En **Environment variables**, crea `PANEL_PASSWORD`, `SESSION_SECRET` y `UPLOAD_TOKEN` con los valores actuales del panel. No los guardes en Git.
3. Publica el sitio y cambia únicamente `url` en `panel_remoto.json` por la nueva URL HTTPS de Netlify.
4. Ejecuta `publicar_estado.py` para que el PC vuelva a enviar el estado.

El panel usa Netlify Functions y Netlify Blobs; GitHub Pages no sirve para esta versión porque no ejecuta la API.
